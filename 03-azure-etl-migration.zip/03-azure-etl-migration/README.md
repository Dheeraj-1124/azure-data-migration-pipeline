# ☁️ On-Prem SQL Server → Azure Data Lake → Synapse Migration Pipeline

A production-style incremental data migration pipeline that moves order data from an on-prem SQL Server system into Azure Data Lake Storage Gen2 (curated Parquet, partitioned) and then into Azure Synapse Analytics — modeled as both a runnable Python ETL pipeline **and** an equivalent Azure Data Factory pipeline definition.

![Azure](https://img.shields.io/badge/Azure-Data%20Factory%20%7C%20ADLS%20Gen2%20%7C%20Synapse-0078D4?logo=microsoftazure)
![Python](https://img.shields.io/badge/Python-ETL-blue?logo=python)
![Status](https://img.shields.io/badge/Status-Runnable%20Locally-brightgreen)

## 🏗️ Architecture
```
On-Prem SQL Server (Orders)
        │  Self-Hosted Integration Runtime
        ▼
Azure Data Lake Storage Gen2  (raw zone)
        │  Data Flow: cleanse, impute, standardize schema
        ▼
Azure Data Lake Storage Gen2  (curated zone, Parquet, partitioned by month)
        │  PolyBase bulk load
        ▼
Azure Synapse Analytics (dbo.FactOrders)
        │
        ▼
Power BI / downstream analytics
```
Incremental loads are watermark-based (`ModifiedDate`), so only new/changed records move on each run — this is the same pattern used in real enterprise ADF pipelines.

## 🧰 Tools & Stack
`Azure Data Factory` · `Azure Data Lake Storage Gen2` · `Azure Synapse Analytics` · `Python` · `Pandas` · `PyArrow` · `azure-storage-blob SDK` · `SQLAlchemy`

## 📂 Structure
```
03-azure-etl-migration/
├── src/
│   ├── extract.py          # Extract from on-prem source
│   ├── transform.py        # Cleansing, imputation, schema standardization
│   ├── load_to_azure.py    # Load to ADLS Gen2 + Synapse (real SDK, local fallback)
│   └── main.py              # Orchestrates the full E-T-L run
├── pipeline/
│   └── adf_pipeline_definition.json   # Equivalent Azure Data Factory pipeline (JSON)
├── sample_data/onprem_orders.csv      # Sample dirty source data (nulls, missing fields)
└── requirements.txt
```

## ⚙️ Two Ways to Read This Project
1. **`pipeline/adf_pipeline_definition.json`** — shows the pipeline exactly as it would be authored/deployed in Azure Data Factory (Copy activities, Data Flow, watermark lookup, PolyBase load to Synapse, daily trigger).
2. **`src/`** — the same logic expressed as runnable Python, so anyone cloning the repo can execute the full pipeline locally with zero Azure setup (falls back to a local `azure_emulator/` folder instead of real ADLS/Synapse when no connection string is set).

## ▶️ Run It
```bash
pip install -r requirements.txt
cd src && python main.py
```
To point it at real Azure resources instead of the local emulator:
```bash
export AZURE_STORAGE_CONNECTION_STRING="<your ADLS Gen2 connection string>"
export SYNAPSE_CONNECTION_STRING="<your Synapse SQLAlchemy connection string>"
python main.py
```

## 🧹 Data Quality Handled
The sample source data intentionally includes real-world messiness the pipeline resolves:
- Missing customer names → defaulted
- Missing emails → row dropped (critical field for CRM sync)
- Missing quantity → business-rule default of 1
- Missing unit price → imputed with per-product median
- Inconsistent text casing → standardized

## 💡 What This Project Demonstrates
- Designing an incremental (watermark-based), partitioned migration pipeline
- Fluency in both the **ADF visual/JSON pipeline model** and **Python-based ETL**
- Real data-quality/cleansing logic, not just a happy-path copy
- Cloud-agnostic pipeline structure that's easy to compare against the GCP version (project 4) of this same migration

---
*Part of a 6-project data portfolio covering Data Analytics, BI Dashboards, Cloud Data Migration, GenAI, and Machine Learning.*
