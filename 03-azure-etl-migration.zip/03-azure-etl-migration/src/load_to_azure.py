"""
Load layer — writes the transformed dataset to Azure Data Lake Storage Gen2
(as Parquet, partitioned by year-month) and then to Azure Synapse Analytics.

This uses the real `azure-storage-blob` / `azure-identity` SDKs when Azure
credentials are present in the environment. When they aren't (e.g. running
this repo locally/in CI without an Azure subscription), it transparently
falls back to writing the same partitioned Parquet output to a local
`./azure_emulator/` folder — so the full pipeline is always runnable end-to-end.
"""
import os
import logging
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("load")

AZURE_STORAGE_CONN_STR = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
ADLS_CONTAINER = os.getenv("ADLS_CONTAINER", "curated")
LOCAL_EMULATOR_DIR = "./azure_emulator"


def load_to_adls(df: pd.DataFrame) -> list[str]:
    """Writes df to ADLS Gen2, partitioned by order_year_month, as Parquet."""
    written_paths = []

    if AZURE_STORAGE_CONN_STR:
        # ---- Real Azure path ----
        from azure.storage.blob import BlobServiceClient
        import io

        blob_service = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONN_STR)
        container_client = blob_service.get_container_client(ADLS_CONTAINER)

        for period, part_df in df.groupby("order_year_month"):
            buf = io.BytesIO()
            part_df.to_parquet(buf, index=False)
            buf.seek(0)
            blob_path = f"orders/order_year_month={period}/orders.parquet"
            container_client.upload_blob(name=blob_path, data=buf, overwrite=True)
            written_paths.append(f"abfss://{ADLS_CONTAINER}@<account>.dfs.core.windows.net/{blob_path}")
            logger.info(f"Uploaded partition {period} to ADLS: {blob_path}")
    else:
        # ---- Local emulator fallback (default for this repo) ----
        logger.warning("AZURE_STORAGE_CONNECTION_STRING not set — writing to local ADLS emulator "
                        f"at {LOCAL_EMULATOR_DIR}/ instead of real Azure Storage.")
        for period, part_df in df.groupby("order_year_month"):
            part_dir = f"{LOCAL_EMULATOR_DIR}/orders/order_year_month={period}"
            os.makedirs(part_dir, exist_ok=True)
            out_path = f"{part_dir}/orders.parquet"
            part_df.to_parquet(out_path, index=False)
            written_paths.append(out_path)
            logger.info(f"Wrote partition {period} -> {out_path}")

    return written_paths


def load_to_synapse(df: pd.DataFrame, table_name: str = "dbo.FactOrders") -> None:
    """
    Loads the curated dataset into Azure Synapse Analytics (dedicated SQL pool).

    Production equivalent (using sqlalchemy + pyodbc, ODBC Driver 18 for SQL Server):
        engine = create_engine(SYNAPSE_CONN_STR)
        df.to_sql(table_name, engine, if_exists="append", index=False, method="multi", chunksize=1000)
    """
    synapse_conn_str = os.getenv("SYNAPSE_CONNECTION_STRING")
    if synapse_conn_str:
        from sqlalchemy import create_engine
        engine = create_engine(synapse_conn_str)
        df.to_sql(table_name.split(".")[-1], engine, if_exists="append", index=False,
                  method="multi", chunksize=1000)
        logger.info(f"Loaded {len(df)} rows into Synapse table {table_name}")
    else:
        logger.warning("SYNAPSE_CONNECTION_STRING not set — simulating Synapse load locally.")
        os.makedirs(LOCAL_EMULATOR_DIR, exist_ok=True)
        out_path = f"{LOCAL_EMULATOR_DIR}/{table_name.split('.')[-1]}.csv"
        df.to_csv(out_path, index=False)
        logger.info(f"Simulated Synapse load -> {out_path} ({len(df)} rows)")
