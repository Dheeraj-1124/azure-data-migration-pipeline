"""
Extract layer — simulates pulling data from an on-prem SQL Server source system.
In production this would use pyodbc/SQLAlchemy against the real SQL Server instance;
here it reads the equivalent sample export so the pipeline is runnable without
provisioning infrastructure.
"""
import pandas as pd
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("extract")


def extract_onprem_orders(path: str = "../sample_data/onprem_orders.csv") -> pd.DataFrame:
    """
    Extracts raw order records from the on-prem source.

    Production equivalent:
        conn = pyodbc.connect(ONPREM_SQL_CONN_STR)
        df = pd.read_sql("SELECT * FROM dbo.Orders WHERE ModifiedDate >= ?", conn, params=[last_watermark])
    """
    logger.info(f"Extracting orders from on-prem source: {path}")
    df = pd.read_csv(path)
    logger.info(f"Extracted {len(df)} raw records")
    return df


if __name__ == "__main__":
    df = extract_onprem_orders()
    print(df.head())
