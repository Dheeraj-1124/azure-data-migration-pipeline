"""
Pipeline orchestrator — runs the full Extract -> Transform -> Load flow.
Mirrors the activity sequence of the Azure Data Factory pipeline defined in
../pipeline/adf_pipeline_definition.json, so it can be run/demoed locally
without deploying to Azure.

Run: python main.py
"""
import logging
from extract import extract_onprem_orders
from transform import clean_and_transform
from load_to_azure import load_to_adls, load_to_synapse

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("pipeline")


def run_pipeline():
    logger.info("=== On-Prem SQL Server -> Azure Data Lake -> Synapse migration pipeline START ===")

    raw_df = extract_onprem_orders()
    clean_df = clean_and_transform(raw_df)

    adls_paths = load_to_adls(clean_df)
    load_to_synapse(clean_df)

    logger.info(f"Pipeline complete. {len(clean_df)} records migrated across {len(adls_paths)} partitions.")
    return clean_df


if __name__ == "__main__":
    run_pipeline()
