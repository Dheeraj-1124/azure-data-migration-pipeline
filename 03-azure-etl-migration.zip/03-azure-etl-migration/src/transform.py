"""
Transform layer — cleans, validates, and reshapes raw on-prem data into the
target schema expected by Azure Synapse / the analytics data model.
"""
import pandas as pd
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("transform")


def clean_and_transform(df: pd.DataFrame) -> pd.DataFrame:
    logger.info("Starting transformation")
    df = df.copy()

    rows_before = len(df)

    # 1. Handle missing customer names
    df["customer_name"] = df["customer_name"].fillna("Unknown Customer")

    # 2. Drop rows with no email (critical field for downstream CRM sync)
    df = df.dropna(subset=["customer_email"])

    # 3. Fill missing quantity with 1 (business rule: assume single unit if unspecified)
    df["qty"] = df["qty"].fillna(1).astype(int)

    # 4. Impute missing unit_price with the product's median price
    df["unit_price"] = df.groupby("product")["unit_price"].transform(
        lambda s: s.fillna(s.median())
    )

    # 5. Derive standardized fields for the target schema
    df["order_date"] = pd.to_datetime(df["order_date"])
    df["total_amount"] = (df["qty"] * df["unit_price"]).round(2)
    df["order_year_month"] = df["order_date"].dt.to_period("M").astype(str)
    df["ingestion_timestamp"] = pd.Timestamp.utcnow()

    # 6. Standardize text fields
    df["country"] = df["country"].str.strip().str.title()
    df["customer_email"] = df["customer_email"].str.strip().str.lower()

    # 7. Reorder / select target schema columns
    target_cols = [
        "order_id", "customer_name", "customer_email", "country",
        "order_date", "order_year_month", "product", "qty", "unit_price",
        "total_amount", "ingestion_timestamp",
    ]
    df = df[target_cols]

    logger.info(f"Transformation complete: {rows_before} -> {len(df)} rows "
                f"({rows_before - len(df)} dropped for missing critical fields)")
    return df


if __name__ == "__main__":
    from extract import extract_onprem_orders
    raw = extract_onprem_orders()
    clean = clean_and_transform(raw)
    print(clean)
